import 'package:flutter/material.dart';

class AppColors {
  static  final buttonColor = Colors.greenAccent.shade700;
  static  final primaryColor = Color(0xFF87CB28);

}
