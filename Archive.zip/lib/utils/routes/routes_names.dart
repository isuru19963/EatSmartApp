class RouteNames {
  static const String login = "login_screen";
  static const String home = "home_screen";
  static const String signupScreen = "sign_up_screen";
  static const String splashScreen = "splash_screen";
  static const String introScreen = "intro_screen";

}
